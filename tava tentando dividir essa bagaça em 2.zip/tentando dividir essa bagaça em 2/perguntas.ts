// Define uma interface para representar um país, incluindo nome, URL da bandeira e perguntas
export interface Pais {
    nome: string;
    urlBandeira: string;
    perguntas: Pergunta[];
}

// Define uma interface para representar uma pergunta, incluindo texto, resposta correta e opções
export interface Pergunta {
    texto: string;
    resposta: string;
    opcoes: string[];
}

// Lista de países com suas respectivas bandeiras e perguntas
export const paises: Pais[] = [
    {
        nome: "Brasil",
        urlBandeira: "https://upload.wikimedia.org/wikipedia/en/0/05/Flag_of_Brazil.svg",
        perguntas: [
            {
                texto: "É o país do futebol...",
                resposta: "Brasil",
                opcoes: ["Venezuela", "Acre", "Brasil", "México"]
            }
        ]
    },
    {
        nome: "Argentina",
        urlBandeira: "https://bandeira.net/wp-content/uploads/2018/08/bandeira-da-argentina-300x187.png",
        perguntas: [
            {
                texto: "São os maiores rivais do Brasil no futebol...",
                resposta: "Argentina",
                opcoes: ["Alemanha", "Angola", "Venezuela", "Argentina"]
            }
        ]
    },
    // Adicione mais países com suas perguntas conforme necessário
];
