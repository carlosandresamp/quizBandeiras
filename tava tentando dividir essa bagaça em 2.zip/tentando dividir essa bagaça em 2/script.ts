// Importa as interfaces e a lista de países do arquivo perguntas.ts
import { Pais, Pergunta, paises } from './perguntas';

// Classe principal que gerencia o jogo de bandeiras
class JogoDeBandeiras {
    private paises: Pais[];
    private pontuacao: number;
    private modoJogar: 'sobrevivencia' | 'aprender';
    private perguntasFeitas: Set<string>; // Armazena as perguntas já feitas
    private paisAtual: Pais | null = null;
    private perguntaAtual: Pergunta | null = null;

    // Construtor da classe que inicializa as propriedades
    constructor(paises: Pais[]) {
        this.paises = paises;
        this.pontuacao = 0;
        this.modoJogar = 'sobrevivencia';
        this.perguntasFeitas = new Set();
        this.configurarBotaoSom();
    }

    // Método para iniciar o jogo em um modo específico
    iniciarJogo(jogar: 'sobrevivencia' | 'aprender') {
        this.pontuacao = 0;
        this.modoJogar = jogar;
        this.perguntasFeitas.clear(); // Limpa as perguntas feitas ao iniciar um novo jogo
        document.getElementById('menu')!.classList.add('escondido');
        document.getElementById('jogo')!.classList.remove('escondido');
        document.getElementById('pontuacao')!.innerText = `Pontuação: ${this.pontuacao}`;
        this.carregarNovaPergunta();
    }

    // Método privado para carregar uma nova pergunta
    private carregarNovaPergunta() {
        let containerBandeira = document.getElementById('container-bandeira');
        if (containerBandeira) {
            containerBandeira.classList.add('escondido');
            containerBandeira.innerHTML = '';
        }

        let containerPergunta = document.getElementById('container-pergunta');
        if (containerPergunta) {
            containerPergunta.innerHTML = '';
        }

        // Combinação de todas as perguntas dos países
        let todasPerguntas = ([] as Pergunta[]).concat(...this.paises.map(pais => pais.perguntas));

        // Filtra as perguntas que ainda não foram feitas
        let perguntasRestantes = todasPerguntas.filter(pergunta => !this.perguntasFeitas.has(pergunta.texto));

        if (perguntasRestantes.length === 0) {
            this.exibirFimDeJogo(); // Se não houver mais perguntas, exibe o fim de jogo
            return;
        }

        // Seleciona uma nova pergunta aleatória
        this.perguntaAtual = perguntasRestantes[Math.floor(Math.random() * perguntasRestantes.length)];
        this.perguntasFeitas.add(this.perguntaAtual.texto); // Marca a pergunta como feita

        // Encontra o país atual com base na pergunta selecionada
        this.paisAtual = this.paises.find(pais => pais.perguntas.includes(this.perguntaAtual!)) || null;

        let containerOpcoes = document.getElementById('container-opcoes');
        if (containerOpcoes && containerPergunta) {
            containerPergunta.innerHTML = `<h3>${this.perguntaAtual!.texto}</h3>`;

            // Embaralha as opções de resposta
            let opcoes = this.perguntaAtual!.opcoes.slice();
            this.embaralharArray(opcoes);
            containerOpcoes.innerHTML = opcoes.map(opcao => `<button onclick="jogo.verificarResposta('${opcao}')">${opcao}</button>`).join('');
        }
    }

    // Método para verificar a resposta escolhida pelo jogador
    verificarResposta(selecionado: string) {
        if (selecionado === this.perguntaAtual!.resposta) {
            this.pontuacao++;
            document.getElementById('pontuacao')!.innerText = `Pontuação: ${this.pontuacao}`;

            let containerBandeira = document.getElementById('container-bandeira');
            if (containerBandeira) {
                containerBandeira.innerHTML = `<h2>${this.paisAtual!.nome}, você acertou!</h2>
                                        <img src="${this.paisAtual!.urlBandeira}" alt="Bandeira" class="bandeira">`;
                containerBandeira.classList.remove('escondido');
            }

            setTimeout(() => this.carregarNovaPergunta(), 3000);
        } else if (this.modoJogar === 'sobrevivencia') {
            this.exibirFimDeJogo();
        } else {
            this.carregarNovaPergunta();
        }
    }

    // Método para exibir a tela de fim de jogo
    private exibirFimDeJogo() {
        document.getElementById('jogo')!.classList.add('escondido');
        let fimDeJogoContainer = document.getElementById('fim-de-jogo');
        if (fimDeJogoContainer) {
            fimDeJogoContainer.classList.remove('escondido');
        }
    }

    // Método para tentar novamente no modo sobrevivência
    tentarNovamente() {
        let fimDeJogoContainer = document.getElementById('fim-de-jogo');
        if (fimDeJogoContainer) {
            fimDeJogoContainer.classList.add('escondido');
        }
        document.getElementById('jogo')!.classList.remove('escondido');
        this.pontuacao = 0;
        document.getElementById('pontuacao')!.innerText = `Pontuação: ${this.pontuacao}`;
        this.perguntasFeitas.clear();
        this.carregarNovaPergunta();
    }

    // Método para retornar ao menu principal
    retornarAoMenu() {
        let fimDeJogoContainer = document.getElementById('fim-de-jogo');
        if (fimDeJogoContainer) {
            fimDeJogoContainer.classList.add('escondido');
        }
        document.getElementById('menu')!.classList.remove('escondido');
    }

    // Método privado para embaralhar um array (utilizado para embaralhar as opções)
    private embaralharArray(array: any[]) {
        for (let i = array.length - 1; i > 0; i--) {
            let j = Math.floor(Math.random() * (i + 1));
            [array[i], array[j]] = [array[j], array[i]];
        }
    }

    // Método para configurar o botão de som
    private configurarBotaoSom() {
        let botaoSom = document.getElementById('toggle-som') as HTMLButtonElement;
        let musica = document.getElementById('musica') as HTMLAudioElement;
        let somAtivado = true;

        botaoSom.addEventListener('click', () => {
            if (somAtivado) {
                musica.pause();
                botaoSom.innerText = 'Ativar Som';
            } else {
                musica.play();
                botaoSom.innerText = 'Desativar Som';
            }
            somAtivado = !somAtivado;
        });
    }
}

// Cria uma instância do jogo de bandeiras
const jogo = new JogoDeBandeiras(paises);

// Exponha os métodos no objeto global para que possam ser chamados a partir do HTML
(window as any).iniciarJogo = (jogar: 'sobrevivencia' | 'aprender') => jogo.iniciarJogo(jogar);
(window as any).tentarNovamente = () => jogo.tentarNovamente();
(window as any).retornarAoMenu = () => jogo.retornarAoMenu();
